var config = {
    map: {
        '*': {
            label: 'js/owl.carousel.min',
            
        }
    },
    shim: {
        'label': {
            deps: ['jquery']
        }
    }
};
