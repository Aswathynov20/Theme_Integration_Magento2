var config = {
    map: {
        '*': {
            label: 'js/owl.carousel.min',
            label:'js/wishlist',
            label:'js/addtocart',
        }
    },
    shim: {
        'label': {
            deps: ['jquery']
        }
    }
};
